export enum ThemeTypesEnum {
  DARK = "dark",
  LIGHT = "light",
}
