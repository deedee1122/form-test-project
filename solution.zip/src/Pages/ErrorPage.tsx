import React from "react";

const ErrorPage = () => {
  return <div>This page doesn't exist, please go back to home page </div>;
};

export default ErrorPage;
