import Home from "./Home";
import ErrorPage from "./ErrorPage";

export { ErrorPage, Home };
